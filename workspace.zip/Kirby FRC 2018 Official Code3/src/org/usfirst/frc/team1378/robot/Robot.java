package org.usfirst.frc.team1378.robot;

import edu.wpi.first.wpilibj.CameraServer;
import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.GenericHID.Hand;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.Scheduler;
import edu.wpi.first.wpilibj.networktables.NetworkTable;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.Timer;

import org.usfirst.frc.team1378.robot.commands.LeftTurn;
import org.usfirst.frc.team1378.robot.commands.MidBaseline;
import org.usfirst.frc.team1378.robot.commands.MidSwitchRight;
import org.usfirst.frc.team1378.robot.commands.NoAuto;
import org.usfirst.frc.team1378.robot.commands.RightTurn;
import org.usfirst.frc.team1378.robot.commands.SideBaseline;
import org.usfirst.frc.team1378.robot.commands.SideSwitchLeft;
import org.usfirst.frc.team1378.robot.commands.SideSwitchRight;
import org.usfirst.frc.team1378.robot.subsystems.*;

import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.FeedbackDevice;
import com.ctre.phoenix.motorcontrol.StatusFrameEnhanced;
import com.ctre.phoenix.motorcontrol.can.TalonSRX;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;

public class Robot extends IterativeRobot {
	//Variables
	public static final Drive drive = new Drive();
	public static final Lift lift = new Lift();
	public static final Roller roller = new Roller();
	public static final Arm arm = new Arm();
	public static final GearShifter gs = new GearShifter();
	protected static Compressor comp;
	public static OI m_oi;
	boolean toggleButton;
	boolean toggleButton2;
	String GearShift;
	String GearShift1;
	double MatchTime;
	double BatteryVoltage;
	public static OI oi;
	public String gameData;
	
	XboxController joystk = new XboxController(RobotMap.joystk);
	double LYAxis, RYAxis;
	
	Command m_autonomousCommand;
	SendableChooser<Command> m_chooser = new SendableChooser<>();
	public void robotInit() {
		//Auto Chooser
		m_oi = new OI();
		m_chooser.addObject("NoAuto", new NoAuto()); //pos: nothing
		m_chooser.addObject("SideBaselineRev", new SideBaseline()); //pos: backwards
		m_chooser.addObject("MidBaseRev", new MidBaseline()); //pos: backwards
		m_chooser.addObject("SideSwitchLeft", new SideSwitchLeft());
		m_chooser.addObject("MidSwitch", new MidSwitchRight());
		m_chooser.addDefault("SideSwitchRight", new SideSwitchRight());
		SmartDashboard.putData("Auto mode", m_chooser);
		
		// Camera
		CameraServer USBCamera = CameraServer.getInstance();
		USBCamera.startAutomaticCapture(RobotMap.UCN);
		oi = new OI();
		//Compressor On & Clear Sticky Faults
		comp = new Compressor(0);
		comp.clearAllPCMStickyFaults();
		comp.setClosedLoopControl(true);
	}
	@Override
	public void disabledInit() {
	}
	@Override
	public void disabledPeriodic() {
		Scheduler.getInstance().run();
	}
	@Override
	public void autonomousInit() {
		m_autonomousCommand = m_chooser.getSelected();
		if (m_autonomousCommand != null) {
			m_autonomousCommand.start();
		}
		gameData = DriverStation.getInstance().getGameSpecificMessage();
	}
	@Override
	public void autonomousPeriodic() {
		gameData = DriverStation.getInstance().getGameSpecificMessage();
		Scheduler.getInstance().run();
	}
	@Override
	public void teleopInit() {
		if (m_autonomousCommand != null) {
			m_autonomousCommand.cancel();
		}
	}
	@Override
	public void teleopPeriodic() {
		
		//Drive
		LYAxis = joystk.getY(Hand.kLeft);
		RYAxis = joystk.getY(Hand.kRight);
		drive.TeleopControl(LYAxis, RYAxis);
		
		//Roller
		roller.run(joystk.getRawButton(6), joystk.getTriggerAxis(Hand.kRight));
		
		//Arm
		arm.Down(joystk.getPOV());
		arm.Up(joystk.getPOV());
		
		//Gear Shifter Drive
		if (joystk.getRawButtonPressed(1)) {
			toggleButton = !toggleButton;
		}
		else if (joystk.getRawButton(2))
		{
			toggleButton2 = !toggleButton;
		}
		gs.run(toggleButton);
		gs.runlift(toggleButton2);
		
		//Lift
		lift.Run(joystk.getRawButton(5), joystk.getTriggerAxis(Hand.kLeft));
		
		//Gear Shifting Status
		if(toggleButton) {	
			GearShift = "Low";
		}
		else if(!toggleButton) {
			GearShift = "High";
		}
		if(toggleButton2) {	
			GearShift1 = "Low";
		}
		else if(!toggleButton2) {
			GearShift1 = "High";
		}
		if(GearShift == "Low")
		{
			comp.stop();
		}
		else if(GearShift == "High")
		{
			comp.start();
		}
		//Driver Station
		MatchTime = DriverStation.getInstance().getMatchTime();
		BatteryVoltage = DriverStation.getInstance().getBatteryVoltage();
		
		SmartDashboard.putString("DriveGearShiftStatus", GearShift);
		SmartDashboard.putString("LiftGearShiftStatus", GearShift1);
		SmartDashboard.putNumber("MatchTimer:", MatchTime);
		SmartDashboard.putNumber("Battery Voltage:", BatteryVoltage);
		Scheduler.getInstance().run();
	}
}