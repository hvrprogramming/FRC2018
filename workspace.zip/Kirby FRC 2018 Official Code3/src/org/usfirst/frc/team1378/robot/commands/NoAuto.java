package org.usfirst.frc.team1378.robot.commands;

import edu.wpi.first.wpilibj.command.Command;
import org.usfirst.frc.team1378.robot.Robot;

public class NoAuto extends Command {
	public NoAuto() {
	}
	@Override
	protected void initialize() {
	}
	@Override
	protected void execute() {
	}
	@Override
	protected boolean isFinished() {
		return false;
	}
	@Override
	protected void end() {	
	}
	@Override
	protected void interrupted() {
	}
}