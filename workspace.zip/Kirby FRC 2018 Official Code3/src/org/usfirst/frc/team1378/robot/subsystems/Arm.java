package org.usfirst.frc.team1378.robot.subsystems;

import org.usfirst.frc.team1378.robot.RobotMap;

import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.FeedbackDevice;
import com.ctre.phoenix.motorcontrol.can.TalonSRX;

import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

public class Arm extends Subsystem{

	protected static TalonSRX TSRXRA;
	protected void initDefaultCommand() {
		/*Rotating Arm */
		TSRXRA = new TalonSRX(RobotMap.TSRXRA); //Talon SRX Rotating Arm Initialization | Can ID: 4
		TSRXRA.setInverted(false);
	}
	public void Up (int POV)
	{
		if(POV == 0)
		{
			TSRXRA.set(ControlMode.PercentOutput, -0.80);
	
		}
		else {
			TSRXRA.set(ControlMode.PercentOutput, 0);
			
		}
	}
	public void Down (int POV)
	{
		if(POV == 180)
		{
			TSRXRA.set(ControlMode.PercentOutput, 0.60);
		}
		else {
			TSRXRA.set(ControlMode.PercentOutput, 0);
		}
	}
	public void RunDown ()
	{
		TSRXRA.set(ControlMode.PercentOutput, 0.5);
	}
	public void done()
	{
		TSRXRA.set(ControlMode.PercentOutput, 0);
	}
}