package org.usfirst.frc.team1378.robot.subsystems;

import org.usfirst.frc.team1378.robot.RobotMap;

import edu.wpi.first.wpilibj.DoubleSolenoid;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Subsystem;

public class GearShifter extends Subsystem {

	protected static DoubleSolenoid GS1,GS2;
    public void initDefaultCommand() {
    	GS1 = new DoubleSolenoid(RobotMap.GS1, RobotMap.GS2);
    	GS2 = new DoubleSolenoid(RobotMap.GS3, RobotMap.GS4);
    }
    
    public void run(boolean toggleButton)
    {
    	if(toggleButton) {
    		GS1.set(DoubleSolenoid.Value.kForward); //Low
    	}
    	else if (!toggleButton) {
    		GS1.set(DoubleSolenoid.Value.kReverse); //High
    	}
    }
    public void runlift(boolean toggleButton2)
    {
    	if(toggleButton2) {
    		GS2.set(DoubleSolenoid.Value.kForward);
    	}
    	else if(!toggleButton2) {
    		GS2.set(DoubleSolenoid.Value.kReverse);
    	}
    }
}