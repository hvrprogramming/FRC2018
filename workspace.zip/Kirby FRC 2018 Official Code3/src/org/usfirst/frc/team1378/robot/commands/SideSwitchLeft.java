package org.usfirst.frc.team1378.robot.commands;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.command.CommandGroup;

public class SideSwitchLeft extends CommandGroup {
	public SideSwitchLeft()
	{
		String gameData = DriverStation.getInstance().getGameSpecificMessage();
		if(gameData.length() > 0)
		{
			if(gameData.charAt(0) == 'L')
			{
				addSequential(new SideBaseline());
				addSequential(new ArmFlipDown());
				addSequential(new Lift());
				addSequential(new LeftTurn());
				addSequential(new FillDistance());
				addSequential(new RollerOut());
			}
			else
			{
				addSequential(new SideBaseline());
			}
		}
	}
}