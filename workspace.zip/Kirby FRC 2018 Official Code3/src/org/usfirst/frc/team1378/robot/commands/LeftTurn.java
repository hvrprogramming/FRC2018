package org.usfirst.frc.team1378.robot.commands;

import edu.wpi.first.wpilibj.command.Command;
import org.usfirst.frc.team1378.robot.Robot;

public class LeftTurn extends Command {
	public LeftTurn() {
		setTimeout(1.7);
	}
	@Override
	protected void initialize() {
	}
	@Override
	protected void execute() {
		Robot.drive.DriveTurnRight(0.9, 0.9);
		Robot.roller.RunAutonIn(0.6);
	}
	@Override
	protected boolean isFinished() {
		return isTimedOut();
	}
	@Override
	protected void end() {
		Robot.drive.DriveControl(0,0);
		Robot.roller.RunAutonIn(0);
	}
	@Override
	protected void interrupted() {
		end();
	}
}