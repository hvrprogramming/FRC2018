package org.usfirst.frc.team1378.robot.commands;

import edu.wpi.first.wpilibj.command.Command;
import org.usfirst.frc.team1378.robot.Robot;

public class ArmFlipDown extends Command {
	public ArmFlipDown() {
		setTimeout(1.5);
	}
	@Override
	protected void initialize() {
	}
	@Override
	protected void execute() {
		Robot.arm.RunDown();
	}
	@Override
	protected boolean isFinished() {
		return isTimedOut();
	}
	@Override
	protected void end() {
		Robot.arm.done();
	}
	@Override
	protected void interrupted() {
		end();
	}
}