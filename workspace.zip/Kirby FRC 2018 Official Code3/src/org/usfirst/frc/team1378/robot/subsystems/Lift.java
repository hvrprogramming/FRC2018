package org.usfirst.frc.team1378.robot.subsystems;

import org.usfirst.frc.team1378.robot.RobotMap;

import com.ctre.phoenix.motorcontrol.FeedbackDevice;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;

import edu.wpi.first.wpilibj.VictorSP;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

public class Lift extends Subsystem{
	protected static WPI_TalonSRX TSRXEL;
	protected static VictorSP VSPEL1,VSPEL2;
	protected void initDefaultCommand() {
		/** Talon SRX **/
		TSRXEL = new WPI_TalonSRX(RobotMap.TSRXEL); //Talon SRX Left Drive Initialization | Can ID: 1
		TSRXEL.setInverted(false);
		TSRXEL.configSelectedFeedbackSensor(FeedbackDevice.CTRE_MagEncoder_Relative,0,10); //Talon SRX RD CTRE
		TSRXEL.setSensorPhase(true);
		TSRXEL.setSelectedSensorPosition(0, 0, 0);
		
		/** Victor SP **/
		VSPEL1 = new VictorSP(RobotMap.VSPEL1); //Victor SP Left Drive 1 Initialization | Port: 0
		VSPEL1.setInverted(false);
		VSPEL2 = new VictorSP(RobotMap.VSPEL2); //Victor SP Left Drive 2 Initialization | Port: 1
		VSPEL2.setInverted(false);
	}
	public void Run (boolean button, double triggerAxis)
	{
		if(button)
		{
			TSRXEL.set(0.75);
			VSPEL1.set(0.75);
			VSPEL2.set(0.75);
			SmartDashboard.putNumber("L Encoder Pos:", -TSRXEL.getSelectedSensorPosition(0));
			SmartDashboard.putNumber("L Encoder Vel:", TSRXEL.getSelectedSensorVelocity(0));
		}
		else if(triggerAxis > 0)
		{
			TSRXEL.set(-triggerAxis);
			VSPEL1.set(-triggerAxis);
			VSPEL2.set(-triggerAxis);
			SmartDashboard.putNumber("L Encoder Pos:", -TSRXEL.getSelectedSensorPosition(0));
			SmartDashboard.putNumber("L Encoder Vel:", TSRXEL.getSelectedSensorVelocity(0));
		}
		else
		{
			TSRXEL.set(0);
			VSPEL1.set(0);
			VSPEL2.set(0);
			SmartDashboard.putNumber("L Encoder Pos:", -TSRXEL.getSelectedSensorPosition(0));
			SmartDashboard.putNumber("L Encoder Vel:", TSRXEL.getSelectedSensorVelocity(0));
		}
	}
	public void RunAuton(double speed)
	{
		TSRXEL.set(speed);
		VSPEL1.set(speed);
		VSPEL2.set(speed);
	}
	public void SetRunAuton(double distance, double speed)
	{
		if(TSRXEL.getSelectedSensorPosition(0) < distance)
		{
			TSRXEL.set(speed);
			VSPEL1.set(speed);
			VSPEL2.set(speed);
		}
		else
		{
			TSRXEL.set(0);
			VSPEL1.set(0);
			VSPEL2.set(0);
		}
	}
}