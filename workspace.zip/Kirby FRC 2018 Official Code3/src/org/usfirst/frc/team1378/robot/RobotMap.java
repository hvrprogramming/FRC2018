package org.usfirst.frc.team1378.robot;
public class RobotMap {
	/** Talon SRX **/
	/* Drive Train */
	public static int TSRXLD = 1; //Talon SRX Left Drive | Can ID: 3
	public static int TSRXRD = 4; //Talon SRX Right Drive | Can ID: 5
	
	/* Elevator Lift */
	public static int TSRXEL = 3; //Talon SRX Elevator Lift | Can ID: 4
	
	/* Rotating Arm */
	public static int TSRXRA = 2; //Talon SRX Rotating Arm | Can ID: 2
	
	/** Victor SP **/
	/* Drive Train */
	public static int VSPLD1 = 0; //Victor SP Left Drive 1 | Port: 0
	public static int VSPLD2 = 1; //Victor SP Left Drive 2 | Port: 1
	public static int VSPRD1 = 4; //Victor SP Right Drive 1 | Port: 4
	public static int VSPRD2 = 5; //Victor SP Right Drive 2 | Port: 5
	
	/* Elevator Lift */
	public static int VSPEL1 = 2; //Victor SP Elevator Lift 1 | Port: 1
	public static int VSPEL2 = 3; //Victor SP Elevator Lift 2 | Port: 2
	
	/** Victor SPX **/
	public static int VSPXRIR = 5; //Victor SPX Roller Intake 1 | Can ID: 6
	public static int VSPXRIL = 6; //Victor SPX Roller Intake 2 | Can ID: 1
	
	/** Controller **/
	public static int joystk = 0; //Joystick | Port: 0 (Will be assigned to Xbox Controller)
	
	/** Solenoid **/
	public static int GS1 = 6; //Gear Shifter 1 | PCM Port: 6 Drive
	public static int GS2 = 7; //Gear Shifter 2 | PCM Port: 7 Drive
	public static int GS3 = 4; //Gear Shifter 3 | PCM Port: 4 Lift
	public static int GS4 = 5; //Gear Shifter 4 | PCM Port: 5 Lift
	

	public static int UCN = 0;
}