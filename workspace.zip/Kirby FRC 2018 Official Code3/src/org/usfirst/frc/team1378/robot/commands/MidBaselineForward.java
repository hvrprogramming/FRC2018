package org.usfirst.frc.team1378.robot.commands;

import edu.wpi.first.wpilibj.command.Command;
import org.usfirst.frc.team1378.robot.Robot;

public class MidBaselineForward extends Command {
	public MidBaselineForward() {
		setTimeout(3.2);
	}
	@Override
	protected void initialize() {
	}
	@Override
	protected void execute() {
		Robot.drive.DriveControl(-0.6,-0.62);
	}
	@Override
	protected boolean isFinished() {
		return isTimedOut();
	}
	@Override
	protected void end() {
		Robot.drive.DriveControl(0,0);
	}
	@Override
	protected void interrupted() {
		end();
	}
}