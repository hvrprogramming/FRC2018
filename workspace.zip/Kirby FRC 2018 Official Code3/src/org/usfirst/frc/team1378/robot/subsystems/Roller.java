package org.usfirst.frc.team1378.robot.subsystems;

import org.usfirst.frc.team1378.robot.RobotMap;

import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.can.VictorSPX;
import com.ctre.phoenix.motorcontrol.can.WPI_VictorSPX;

import edu.wpi.first.wpilibj.command.Subsystem;

public class Roller extends Subsystem {

	protected static WPI_VictorSPX VSPXRIR,VSPXRIL;
	protected void initDefaultCommand() {
		VSPXRIR = new WPI_VictorSPX (RobotMap.VSPXRIR);
		VSPXRIR.setInverted(false);
		VSPXRIL = new WPI_VictorSPX (RobotMap.VSPXRIL);
		VSPXRIL.setInverted(true);
	}
	public void run (boolean button, double triggerAxis) {
		//In
		if(button) {
			VSPXRIR.set(0.50);
			VSPXRIL.set(-0.50);
		}
		//Out
		else if(triggerAxis > 0) {
			VSPXRIR.set(-triggerAxis);
			VSPXRIL.set(triggerAxis);
		}
		//Nothing
		else {
			VSPXRIR.set(0);
			VSPXRIL.set(0);
		}
	}
	public void RunAutonOut(double speed)
	{
		VSPXRIR.set(-speed);
		VSPXRIL.set(speed);
	}
	public void RunAutonIn(double speed)
	{
		VSPXRIR.set(speed);
		VSPXRIL.set(-speed);
	}
}