package org.usfirst.frc.team1378.robot.commands;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.command.CommandGroup;

public class MidSwitchRight extends CommandGroup {
	public MidSwitchRight()
	{
		String gameData = DriverStation.getInstance().getGameSpecificMessage();
		if(gameData.length() > 0)
		{
			if(gameData.charAt(0) == 'R')
			{
				addSequential(new ArmFlipDown());
				addSequential(new Lift());
				addSequential(new MidBaselineForward());
				addSequential(new RollerOut());	
			}
			else
			{
				addSequential(new MidBaselineForward());
			}
		}
	}
}