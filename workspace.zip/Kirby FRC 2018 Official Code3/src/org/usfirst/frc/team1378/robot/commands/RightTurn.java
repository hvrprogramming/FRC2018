package org.usfirst.frc.team1378.robot.commands;

import edu.wpi.first.wpilibj.command.Command;
import org.usfirst.frc.team1378.robot.Robot;

public class RightTurn extends Command {
	public RightTurn() {
		setTimeout(1.7);
	}
	@Override
	protected void initialize() {
	}
	@Override
	protected void execute() {
		Robot.drive.DriveTurnLeft(0.9, 0.9);
		Robot.roller.RunAutonIn(0.6);
	}
	@Override
	protected boolean isFinished() {
		return isTimedOut();
	}
	@Override
	protected void end() {
		Robot.drive.DriveControl(0,0);
	}
	@Override
	protected void interrupted() {
		end();
	}
}