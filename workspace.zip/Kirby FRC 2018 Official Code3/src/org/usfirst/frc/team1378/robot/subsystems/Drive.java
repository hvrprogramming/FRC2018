package org.usfirst.frc.team1378.robot.subsystems;

import edu.wpi.first.wpilibj.VictorSP;

import com.ctre.phoenix.motorcontrol.FeedbackDevice;
import com.ctre.phoenix.motorcontrol.can.*;

import org.usfirst.frc.team1378.robot.RobotMap;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

public class Drive extends Subsystem {

	protected static WPI_TalonSRX TSRXLD,TSRXRD; //Talon SRX Variables
	protected static VictorSP VSPLD1, VSPLD2, VSPRD1, VSPRD2, VSPEL1, VSPEL2; //Victor SP Variables
	protected static DifferentialDrive DriveUno, DriveDos, DriveTres; //Robot Drive Variables
	protected void initDefaultCommand() {
		/** --- Initialization --- **/
		// -- Motor Controllers -- //
		/** Talon SRX **/
		/* Drive Train */
		TSRXLD = new WPI_TalonSRX(RobotMap.TSRXLD); //Talon SRX Left Drive Initialization | Can ID: 1
		TSRXLD.setInverted(false);
		TSRXRD = new WPI_TalonSRX(RobotMap.TSRXRD); //Talon SRX Right Drive Initialization | Can ID: 4
		TSRXRD.setInverted(false);
		TSRXRD.configSelectedFeedbackSensor(FeedbackDevice.CTRE_MagEncoder_Relative,0,10); //Talon SRX RD CTRE
		TSRXRD.setSensorPhase(true);
		TSRXRD.setSelectedSensorPosition(0, 0, 0);
		
		/** Victor SP **/
		/* Drive Train */
		VSPLD1 = new VictorSP(RobotMap.VSPLD1); //Victor SP Left Drive 1 Initialization | Port: 0
		VSPLD1.setInverted(false);
		VSPLD2 = new VictorSP(RobotMap.VSPLD2); //Victor SP Left Drive 2 Initialization | Port: 1
		VSPLD2.setInverted(false);
		VSPRD1 = new VictorSP(RobotMap.VSPRD1);
		VSPRD1.setInverted(false);
		VSPRD2 = new VictorSP(RobotMap.VSPRD2);
		VSPRD2.setInverted(false);
		
		// -- Drive Train -- //
		DriveUno = new DifferentialDrive (VSPLD1, VSPRD1); //Drive Train 1 Initialization
		DriveDos = new DifferentialDrive (VSPLD2, VSPRD2); //Drive Train 2 Initialization
		DriveTres = new DifferentialDrive (TSRXLD, TSRXRD); //Drive Train 3 Initialization
		DriveUno.setSafetyEnabled(false);
		DriveDos.setSafetyEnabled(false);
		DriveTres.setSafetyEnabled(false);
	}
	public void TeleopControl(double LYAxis, double RYAxis)
    {
		DriveUno.tankDrive(LYAxis*0.85, RYAxis*0.85);
		DriveDos.tankDrive(LYAxis*0.85, RYAxis*0.85);
		DriveTres.tankDrive(LYAxis*0.85, RYAxis*0.85);
		SmartDashboard.putNumber("RD Encoder Pos:", -TSRXRD.getSelectedSensorPosition(0));
		SmartDashboard.putNumber("RD Encoder Vel:", TSRXRD.getSelectedSensorVelocity(0));
    }  
	public void DriveControl(double lspeed, double rspeed)
	{
		DriveUno.setSafetyEnabled(false);
		DriveDos.setSafetyEnabled(false);
		DriveTres.setSafetyEnabled(false);
		DriveUno.tankDrive(lspeed, rspeed);
		DriveDos.tankDrive(lspeed, rspeed);
		DriveTres.tankDrive(lspeed, rspeed);
	}
	public void DriveTurnLeft(double lspeed,double rspeed)
	{
		DriveUno.setSafetyEnabled(false);
		DriveDos.setSafetyEnabled(false);
		DriveTres.setSafetyEnabled(false);
		DriveUno.tankDrive(-lspeed, rspeed);
		DriveDos.tankDrive(-lspeed, rspeed);
		DriveTres.tankDrive(-lspeed, rspeed);
	}
	public void DriveTurnRight(double lspeed,double rspeed)
	{
		DriveUno.setSafetyEnabled(false);
		DriveDos.setSafetyEnabled(false);
		DriveTres.setSafetyEnabled(false);
		DriveUno.tankDrive(lspeed, -rspeed);
		DriveDos.tankDrive(lspeed, -rspeed);
		DriveTres.tankDrive(lspeed, -rspeed);
	}
}