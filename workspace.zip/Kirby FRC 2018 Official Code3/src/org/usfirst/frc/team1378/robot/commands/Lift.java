package org.usfirst.frc.team1378.robot.commands;

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Command;
import org.usfirst.frc.team1378.robot.Robot;

public class Lift extends Command {
	public Lift() {
		setTimeout(1.9);
	}
	@Override
	protected void initialize() {
	}
	@Override
	protected void execute() {
		Robot.lift.RunAuton(0.75);
		Robot.roller.RunAutonIn(0.6);
	}
	@Override
	protected boolean isFinished() {
		return isTimedOut();
	}
	@Override
	protected void end() {
		Robot.lift.RunAuton(0);
		Robot.roller.RunAutonIn(0);
	}
	@Override
	protected void interrupted() {
		end();
	}
}